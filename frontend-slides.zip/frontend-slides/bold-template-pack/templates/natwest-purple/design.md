---
version: 1.0
name: NatWest Purple
description: Formal financial-services presentation system built on the NatWest Group brand identity. Deep purple hero/divider slides bookend clean white content slides. Gold subtitle accents on dark, lilac card fills on light. Playfair Display headings paired with IBM Plex Sans body. Built for investor briefings, internal training, and regulated communications.

colors:
  dark-bg: "#4B0082"
  dark-alt: "#3C1053"
  white: "#FFFFFF"
  offwhite: "#F7F4FB"
  lilac: "#EDD9F5"
  lavender: "#C09FD4"
  gold: "#F5C518"
  mid-purple: "#6B2A8B"
  text-dark: "#3C1053"
  text-body: "#333333"
  text-muted: "#6B2A8B"
  text-hint: "#9B7AB8"
  border-dark: "#6B2A8B"
  border-light: "#C09FD4"

typography:
  h1:
    fontFamily: "'Playfair Display', Georgia, serif"
    fontWeight: 700
    fontSize: "96px"
    lineHeight: 1.06
    letterSpacing: "-0.01em"
    color: "#FFFFFF"
  h2-dark:
    fontFamily: "'Playfair Display', Georgia, serif"
    fontWeight: 700
    fontSize: "58px"
    lineHeight: 1.1
    color: "#FFFFFF"
  h2-light:
    fontFamily: "'Playfair Display', Georgia, serif"
    fontWeight: 700
    fontSize: "52px"
    lineHeight: 1.1
    color: "#3C1053"
  h3:
    fontFamily: "'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif"
    fontWeight: 600
    fontSize: "28px"
    lineHeight: 1.25
    color: "#3C1053"
  subtitle-dark:
    fontFamily: "'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif"
    fontWeight: 400
    fontSize: "22px"
    color: "#F5C518"
  body:
    fontFamily: "'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif"
    fontWeight: 400
    fontSize: "20px"
    lineHeight: 1.65
    color: "#333333"
  label:
    fontFamily: "'IBM Plex Mono', monospace"
    fontWeight: 500
    fontSize: "13px"
    letterSpacing: "0.18em"
    textTransform: "uppercase"
    color: "#F5C518"
  label-light:
    fontFamily: "'IBM Plex Mono', monospace"
    fontWeight: 500
    fontSize: "13px"
    letterSpacing: "0.18em"
    textTransform: "uppercase"
    color: "#6B2A8B"
  section-badge:
    fontFamily: "'IBM Plex Mono', monospace"
    fontWeight: 500
    fontSize: "11px"
    letterSpacing: "0.2em"
    textTransform: "uppercase"
    color: "#C09FD4"
  stat-number:
    fontFamily: "'Playfair Display', Georgia, serif"
    fontWeight: 700
    fontSize: "72px"
    lineHeight: 1
    color: "#3C1053"
  stat-label:
    fontFamily: "'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif"
    fontWeight: 400
    fontSize: "14px"
    color: "#6B2A8B"
  table-header:
    fontFamily: "'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif"
    fontWeight: 700
    fontSize: "14px"
    color: "#FFFFFF"
  table-body:
    fontFamily: "'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif"
    fontWeight: 400
    fontSize: "14px"
    color: "#3C1053"
  footnote:
    fontFamily: "'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif"
    fontWeight: 400
    fontSize: "12px"
    color: "#6B2A8B"

spacing:
  pad-x: "144px"
  pad-y: "56px"
  gap-lg: "40px"
  gap-md: "24px"
  gap-sm: "12px"
  card-pad: "20px 24px"
  table-cell: "14px 20px"

components:
  benefit-box:
    background: "#EDD9F5"
    border: "1px solid #C09FD4"
    borderRadius: "8px"
    padding: "14px 18px"
    fontWeight: 600
    fontStyle: "italic"
    color: "#3C1053"
    description: "Checklist row for value propositions. Lilac fill, lavender border, bold italic deep purple text. Left-side checkbox icon."
  stat-callout:
    textAlign: "center"
    numberColor: "#3C1053"
    numberSize: "72px"
    labelColor: "#6B2A8B"
    labelSize: "14px"
    description: "Key number callout. Large Playfair Display numeral in deep purple, small IBM Plex Sans label below in mid-purple."
  card-filled:
    background: "#EDD9F5"
    border: "1px solid #C09FD4"
    borderRadius: "8px"
    padding: "20px 24px"
    description: "Standard content card on light slides. Lilac fill, lavender border, 8px radius."
  card-white:
    background: "#FFFFFF"
    border: "1px solid #C09FD4"
    borderRadius: "8px"
    padding: "20px 24px"
    description: "White card variant for alternating grids."
  card-dark:
    background: "#4B0082"
    border: "none"
    borderRadius: "8px"
    padding: "20px 24px"
    color: "#FFFFFF"
    description: "Dark purple card for use on light slides when strong contrast is needed."
  table-header-row:
    background: "#4B0082"
    color: "#FFFFFF"
    fontWeight: 700
    fontSize: "14px"
    padding: "14px 20px"
    description: "Table header row. Dark purple fill, white bold text."
  table-row-odd:
    background: "#EDD9F5"
    color: "#3C1053"
    description: "Odd table body rows. Lilac fill."
  table-row-even:
    background: "#FFFFFF"
    color: "#3C1053"
    description: "Even table body rows. White fill."
  section-divider:
    background: "#4B0082"
    badgeColor: "#C09FD4"
    titleColor: "#FFFFFF"
    subtitleColor: "#EDD9F5"
    description: "Full-slide section break. Dark purple bg, small lavender badge above title, white title, pale lilac subtitle."
  chrome-bar-dark:
    background: "#3C1053"
    borderColor: "#6B2A8B"
    labelColor: "#F5C518"
    counterColor: "#8B6BA8"
    description: "Top chrome bar on dark slides. Deep purple bg, gold label, muted counter."
  chrome-bar-light:
    background: "#FFFFFF"
    borderColor: "#C09FD4"
    labelColor: "#6B2A8B"
    counterColor: "#9B7AB8"
    description: "Top chrome bar on light slides. White bg, mid-purple label, hint counter."
  foot-bar-dark:
    background: "#3C1053"
    borderColor: "#6B2A8B"
    textColor: "#8B6BA8"
    description: "Bottom footer bar on dark slides."
  foot-bar-light:
    background: "#FFFFFF"
    borderColor: "#C09FD4"
    textColor: "#9B7AB8"
    description: "Bottom footer bar on light slides."
  nav-btn:
    background: "rgba(75,0,130,0.85)"
    border: "1px solid #6B2A8B"
    color: "#C09FD4"
    hoverColor: "#F5C518"
    hoverBorder: "#F5C518"
    description: "Navigation button. Dark purple tinted bg, lavender text, gold on hover."
  progress-bar:
    background: "#F5C518"
    height: "3px"
    description: "Thin gold progress bar at top of title slide."
---

## Frontend Slides Fixed-Stage Policy

When this design system is used by the `frontend-slides` skill, generate the final deck as a **fixed 1920×1080 stage** that scales uniformly to the browser viewport. The deck preserves a 16:9 slide canvas on every screen; it may letterbox or pillarbox, but must not reflow slide content for mobile.

This policy has higher priority than any responsive behavior described later in this file. Use `deck-stage.js` or an equivalent inline stage scaler for final output.

---

## Overview

NatWest Purple is a **formal financial-services presentation system** built directly on the NatWest Group brand identity. It is designed for investor briefings, internal training, regulatory communications, and any NatWest-branded material that must project institutional authority.

The foundational visual premise is the **dark-light-dark sandwich**: deep purple (`#4B0082`) hero and section-divider slides bookend clean white content slides. This creates visual rhythm — dark slides act as chapter markers and title moments; white slides maximise readability for data-heavy content.

The type system pairs **Playfair Display** (an expressive serif for headings and editorial moments) with **IBM Plex Sans** (a clean, neutral sans for body text and UI chrome). IBM Plex Mono handles labels, counters, and code. This pairing gives the system warmth and authority without relying on the proprietary RN House Sans typeface.

The accent system is disciplined: **gold (`#F5C518`) is used exclusively for subtitle text and labels on dark purple backgrounds**. On white content slides, the accent shifts to **mid-purple (`#6B2A8B`)** for secondary text and **lavender (`#C09FD4`)** for borders and card outlines. Cards use a **pale lilac fill (`#EDD9F5`)** — never solid-colored, never shadowed.

**Key Characteristics:**
- Dark-light-dark sandwich structure for visual rhythm
- Deep purple `#4B0082` on hero/divider slides; white `#FFFFFF` on content slides
- Gold `#F5C518` used only for subtitles and labels on dark backgrounds
- Pale lilac `#EDD9F5` card fills with lavender `#C09FD4` borders
- Playfair Display (headings) + IBM Plex Sans (body) — never substitute
- Left-aligned body text on content slides; centered or left-aligned titles on dark slides
- No decorative accent lines under titles — use background color changes and whitespace instead
- Maximum 3 colors per content slide (deep purple, lavender, white)
- All data points and statistics should include footnote labels per NatWest convention

---

## Colors

### Palette

- **Dark BG** (`#4B0082`): The primary dark surface. Used for title slides, section dividers, and closing slides. Every dark slide rests on this ground.
- **Dark Alt** (`#3C1053`): Deeper purple. Used for chrome bars on dark slides, and as the primary text color on white content slides.
- **White** (`#FFFFFF`): The content slide canvas. Every light slide rests on this ground.
- **Off-White** (`#F7F4FB`): Secondary surface. Used for alternating card fills and zebra table rows.
- **Lilac** (`#EDD9F5`): Card fills, checklist row backgrounds, odd table rows. The signature warm-purple tint that lifts cards off the white canvas.
- **Lavender** (`#C09FD4`): Borders, card outlines, checkbox borders, table cell borders. Never used for body text (fails WCAG AA on white).
- **Gold** (`#F5C518`): Subtitle text on dark backgrounds, chrome labels on dark slides. Used sparingly — this is the Evelyn Partners brand accent and should not appear on white slides.
- **Mid-Purple** (`#6B2A8B`): Section headers, table row labels, secondary text on white slides, chrome labels on light slides.
- **Text Dark** (`#3C1053`): Primary text on white content slides. Headlines, card titles, table body text.
- **Text Body** (`#333333`): Body paragraph text on white slides.
- **Text Muted** (`#6B2A8B`): Secondary text, stat labels, captions on white slides.
- **Text Hint** (`#9B7AB8`): Tertiary text, footnotes, slide counters.

### Color Usage by Slide Type

| Context | Background | Primary Text | Accent |
|---|---|---|---|
| Title / Hero slide | `#4B0082` | `#FFFFFF` | `#F5C518` |
| Section divider slide | `#4B0082` | `#FFFFFF` | `#C09FD4` |
| Content slide | `#FFFFFF` | `#3C1053` | `#6B2A8B` |
| Card fill | `#EDD9F5` | `#3C1053` | `#6B2A8B` (border) |
| Table header row | `#4B0082` | `#FFFFFF` | — |
| Table odd row | `#EDD9F5` | `#3C1053` | — |
| Table even row | `#FFFFFF` | `#3C1053` | — |
| Chrome bar (dark slide) | `#3C1053` | `#F5C518` (label) | `#8B6BA8` (counter) |
| Chrome bar (light slide) | `#FFFFFF` | `#6B2A8B` (label) | `#9B7AB8` (counter) |

### Defaults

- **Default dark slide background**: `#4B0082`
- **Default light slide background**: `#FFFFFF`
- **Default headline on dark**: `#FFFFFF`
- **Default headline on light**: `#3C1053`
- **Default subtitle on dark**: `#F5C518` (gold)
- **Default body text on light**: `#333333`
- **Default card fill**: `#EDD9F5`
- **Default card border**: `1px solid #C09FD4`
- **Default card border-radius**: `8px`
- **Do not use** `#C09FD4` (lavender) for body text on white — it fails WCAG AA contrast. Use `#6B2A8B` or `#3C1053` instead.
- **Do not use** `#F5C518` (gold) on white backgrounds — insufficient contrast for body text. Gold is a dark-slide-only accent.

---

## Typography

### Font Family Stack

**Playfair Display** (Google Fonts, weights 400–700) is the display and heading face. Used for h1 on title slides, h2 on all slides, section titles on divider slides, and stat callout numbers. Its high-contrast serif character projects authority and editorial weight appropriate for financial communications.

**IBM Plex Sans** (Google Fonts, weights 300–600) is the body and UI face. Used for subtitles, body paragraphs, bullet lists, table content, card body text, and all chrome elements. Its clean geometric-humanist character reads as modern and trustworthy.

**IBM Plex Mono** (Google Fonts, weights 400–500) is the label and code face. Used for chrome bar labels, slide counters, section badges, kicker labels, and any code snippets.

### Google Fonts Import

```html
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400;1,600;1,700&family=IBM+Plex+Sans:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
```

### CSS Variables

```css
:root {
  /* NatWest brand palette */
  --nw-dark:          #4B0082;
  --nw-dark-alt:      #3C1053;
  --nw-white:         #FFFFFF;
  --nw-offwhite:      #F7F4FB;
  --nw-lilac:         #EDD9F5;
  --nw-lavender:      #C09FD4;
  --nw-gold:          #F5C518;
  --nw-mid:           #6B2A8B;
  --nw-text:          #3C1053;
  --nw-body:          #333333;
  --nw-muted:         #6B2A8B;
  --nw-hint:          #9B7AB8;
  --nw-border-dark:   #6B2A8B;
  --nw-border-light:  #C09FD4;

  /* Typography */
  --ff-serif:  'Playfair Display', Georgia, serif;
  --ff-sans:   'IBM Plex Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif;
  --ff-mono:   'IBM Plex Mono', monospace;

  /* Spacing */
  --pad-x:  144px;
  --pad-y:  56px;
  --gap-lg: 40px;
  --gap-md: 24px;
  --gap-sm: 12px;

  /* Easing */
  --ease-expo: cubic-bezier(0.16, 1, 0.3, 1);
}
```

---

## Layout

### The Sandwich Structure

Every deck follows the dark-light-dark sandwich:

```
Slide 1:    DARK   — Title / hero (purple bg)
Slides 2+:  LIGHT  — Content (white bg)
Section X:  DARK   — Section divider (purple bg)
Content:    LIGHT  — Content slides
...
Last:       DARK   — Closing / takeaways (purple bg)
```

### Slide Anatomy

**Dark (hero/divider) slides:**
- Background: `#4B0082`
- Subtle grid texture overlay: `linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px)` at 80px
- Title: white, Playfair Display 700, 96px (hero) or 80px (divider)
- Subtitle / deck label: gold `#F5C518`, IBM Plex Sans 400, 22px
- Section badge (dividers only): small lavender `#C09FD4` label above title, IBM Plex Mono, 11px, uppercase, 0.2em tracking
- Gold progress bar: 3px top edge on title slide only
- No body text on dark slides — these are transition/title moments only

**Light (content) slides:**
- Background: `#FFFFFF`
- Title: `#3C1053`, Playfair Display 700, 52px, left-aligned
- Body: `#333333`, IBM Plex Sans 400, 20px, left-aligned
- Kicker label above title: IBM Plex Mono, 13px, uppercase, 0.18em tracking, `#6B2A8B`
- Minimum `144px` horizontal padding, `56px` vertical padding
- `24px` gap between content blocks

### Chrome Bars

Every content slide has a top chrome bar and bottom footer bar:

```css
.chrome-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 var(--pad-x);
  height: 60px;
  border-bottom: 1px solid var(--nw-border-light);
  background: var(--nw-white);
  flex-shrink: 0;
}
.chrome-label {
  font-family: var(--ff-mono);
  font-size: 13px;
  font-weight: 500;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  color: var(--nw-muted);
}
.chrome-counter {
  font-family: var(--ff-mono);
  font-size: 13px;
  color: var(--nw-hint);
}
.foot-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 var(--pad-x);
  height: 52px;
  border-top: 1px solid var(--nw-border-light);
  background: var(--nw-white);
  flex-shrink: 0;
}
```

### Two-Column Layout

Standard content layout for slides with text + visual:

```css
.two-col {
  display: grid;
  grid-template-columns: 1fr 1fr;
  flex: 1;
  overflow: hidden;
}
.two-col.left-wide  { grid-template-columns: 1.15fr 0.85fr; }
.two-col.right-wide { grid-template-columns: 0.85fr 1.15fr; }
.col-left {
  padding: var(--pad-y) var(--pad-x);
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: var(--gap-md);
}
.col-right {
  padding: var(--pad-y) var(--pad-x);
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: var(--gap-md);
  background: var(--nw-offwhite);
  border-left: 1px solid var(--nw-border-light);
}
```

---

## Components

### Bullet List

```css
.bullet-list { list-style: none; display: flex; flex-direction: column; gap: 10px; }
.bullet-list li {
  display: flex; align-items: baseline; gap: 14px;
  font-family: var(--ff-sans); font-size: 20px; line-height: 1.55; color: var(--nw-body);
}
.bullet-list li::before {
  content: '—'; font-family: var(--ff-mono); color: var(--nw-muted);
  font-size: 13px; flex-shrink: 0;
}
.bullet-list li strong { font-weight: 600; color: var(--nw-text); }
```

### Benefit Box (Checklist Row)

```css
.benefit-box {
  background: var(--nw-lilac);
  border: 1px solid var(--nw-lavender);
  border-radius: 8px;
  padding: 14px 18px;
  display: flex; align-items: center; gap: 12px;
  font-family: var(--ff-sans); font-weight: 600; font-style: italic;
  color: var(--nw-text); margin-bottom: 10px;
}
```

### Stat Callout

```css
.stat-callout { text-align: center; }
.stat-number {
  font-family: var(--ff-serif); font-size: 72px; font-weight: 700;
  color: var(--nw-text); line-height: 1;
}
.stat-label {
  font-family: var(--ff-sans); font-size: 14px;
  color: var(--nw-muted); margin-top: 4px;
}
```

### Card Grid

```css
.card-grid { display: grid; gap: 1px; background: var(--nw-border-light); flex: 1; }
.card-grid-2 { grid-template-columns: 1fr 1fr; }
.card-grid-3 { grid-template-columns: 1fr 1fr 1fr; }
.card-grid-4 { grid-template-columns: 1fr 1fr 1fr 1fr; }
.card {
  background: var(--nw-lilac);
  padding: 32px 36px;
  display: flex; flex-direction: column; gap: 12px;
}
.card.white { background: var(--nw-white); }
.card.dark  { background: var(--nw-dark); }
.card-title {
  font-family: var(--ff-serif); font-size: 26px; font-weight: 600;
  color: var(--nw-text); line-height: 1.2;
}
.card-title em { font-style: italic; color: var(--nw-muted); }
.card.dark .card-title { color: var(--nw-white); }
.card-body {
  font-family: var(--ff-sans); font-size: 18px; line-height: 1.6; color: var(--nw-body);
}
.card.dark .card-body { color: var(--nw-lavender); }
```

### Table

```css
.nw-table { width: 100%; border-collapse: collapse; font-family: var(--ff-sans); font-size: 16px; }
.nw-table th {
  background: var(--nw-dark); color: var(--nw-white);
  font-weight: 700; font-size: 14px; text-align: left;
  padding: 14px 20px; border: 0.5px solid var(--nw-lavender);
}
.nw-table td {
  padding: 12px 20px; border: 0.5px solid var(--nw-lavender);
  color: var(--nw-text); vertical-align: top; line-height: 1.45;
}
.nw-table tr:nth-child(odd)  td { background: var(--nw-lilac); }
.nw-table tr:nth-child(even) td { background: var(--nw-white); }
.nw-table td:first-child { font-family: var(--ff-mono); font-size: 12px; color: var(--nw-muted); }
.nw-table td strong { font-weight: 600; color: var(--nw-text); }
```

### Section Divider Slide

```css
.section-divider {
  background: var(--nw-dark);
  display: flex; flex-direction: column;
  align-items: flex-start; justify-content: center;
  padding: 0 var(--pad-x); gap: var(--gap-md);
}
.section-badge {
  font-family: var(--ff-mono); font-size: 11px; font-weight: 500;
  letter-spacing: 0.2em; text-transform: uppercase; color: var(--nw-lavender);
}
.section-num {
  font-family: var(--ff-serif); font-size: 120px; font-weight: 700;
  color: rgba(192,159,212,0.15); line-height: 1;
}
.section-title {
  font-family: var(--ff-serif); font-size: 80px; font-weight: 700;
  line-height: 1.06; color: var(--nw-white);
}
.section-title em { font-style: italic; color: var(--nw-lavender); }
.section-sub {
  font-family: var(--ff-sans); font-size: 22px;
  color: var(--nw-lilac); max-width: 800px;
}
```

### Reveal Animations

```css
.reveal {
  opacity: 0; transform: translateY(18px);
  transition: opacity 0.6s var(--ease-expo), transform 0.6s var(--ease-expo);
}
.slide.active .reveal { opacity: 1; transform: translateY(0); }
.slide.active .reveal:nth-child(1) { transition-delay: 0.07s; }
.slide.active .reveal:nth-child(2) { transition-delay: 0.16s; }
.slide.active .reveal:nth-child(3) { transition-delay: 0.25s; }
.slide.active .reveal:nth-child(4) { transition-delay: 0.34s; }
.slide.active .reveal:nth-child(5) { transition-delay: 0.43s; }
.slide.active .reveal:nth-child(6) { transition-delay: 0.52s; }
.reveal-fade {
  opacity: 0; transition: opacity 0.75s var(--ease-expo);
}
.slide.active .reveal-fade { opacity: 1; }
.slide.active .reveal-fade:nth-child(1) { transition-delay: 0.1s; }
.slide.active .reveal-fade:nth-child(2) { transition-delay: 0.25s; }
.slide.active .reveal-fade:nth-child(3) { transition-delay: 0.4s; }
```

### Navigation Controls

```css
.deck-controls {
  position: fixed; bottom: 22px; left: 50%; transform: translateX(-50%);
  z-index: 1000; display: flex; align-items: center; gap: 10px;
}
.nav-btn {
  background: rgba(75,0,130,0.88); border: 1px solid var(--nw-border-dark);
  color: var(--nw-lavender); font-family: var(--ff-mono); font-size: 12px;
  letter-spacing: 0.1em; padding: 7px 18px; cursor: pointer;
  transition: color 0.2s, border-color 0.2s; backdrop-filter: blur(8px);
}
.nav-btn:hover { color: var(--nw-gold); border-color: var(--nw-gold); }
.slide-counter-ui {
  font-family: var(--ff-mono); font-size: 11px; letter-spacing: 0.14em;
  color: var(--nw-hint); min-width: 56px; text-align: center;
}
```

---

## Slide Type Reference

| Slide Type | Background | Use |
|---|---|---|
| Title / Hero | `#4B0082` dark | Opening slide — deck title, subtitle in gold, metadata |
| Section Divider | `#4B0082` dark | Chapter break — section badge, large title, subtitle |
| Content (text) | `#FFFFFF` light | Bullets, body text, two-column layouts |
| Content (cards) | `#FFFFFF` light | 2×2 or 3-column card grids with lilac fills |
| Content (table) | `#FFFFFF` light | Data tables with purple header row, lilac/white zebra rows |
| Content (stats) | `#FFFFFF` light | Stat callout grids, key numbers |
| Closing | `#4B0082` dark | Summary, takeaways, next steps |

---

## Do's and Don'ts

**Do:**
- Follow the dark-light-dark sandwich for every deck
- Use gold `#F5C518` only on dark purple backgrounds
- Left-align body text on content slides
- Use `#6B2A8B` or `#3C1053` for all body text on white (never lavender)
- Separate content blocks with at least 24px whitespace
- Include footnote labels for all statistics and data points
- Use bold/regular weight contrast for hierarchy within body text

**Don't:**
- Use accent lines under titles — use background changes and whitespace instead
- Mix the investor palette with full brand palette (red, pink, teal) in the same deck
- Use cream or beige backgrounds — NatWest uses white `#FFFFFF` or off-white `#F7F4FB` only
- Use `#C09FD4` lavender for body text on white — fails WCAG AA
- Use gold `#F5C518` text on white backgrounds — insufficient contrast
- Use more than 3 colors on a single content slide
- Reproduce NatWest or Evelyn Partners logos without authorization
