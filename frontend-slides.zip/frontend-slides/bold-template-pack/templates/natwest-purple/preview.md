# NatWest Purple Preview Card

Use this small file for title-slide previews only. For final deck generation, read the full design doc listed below.

## Files

- Full design doc: `bold-template-pack/templates/natwest-purple/design.md`
- Preview card: `bold-template-pack/templates/natwest-purple/preview.md`

## Selection Metadata

- Slug: `natwest-purple`
- Tagline: Deep NatWest purple with gold subtitle accents and a white content canvas; authoritative financial-services brand.
- Mood: authoritative, professional, trustworthy, formal, financial
- Tone: measured, institutional, polished, considered
- Formality: high
- Density: medium-high
- Scheme: mixed (dark hero/divider slides + white content slides)
- Best for: Internal corporate presentations, investor briefings, regulatory communications, training decks, and any NatWest-branded material. The dark-light-dark sandwich structure creates visual rhythm appropriate for formal financial communications. Strong for data-heavy content, process flows, and structured learning material.
- Avoid for: Consumer-facing marketing, playful or informal contexts, or any deck where the NatWest brand identity would feel out of place.

## Visual Snapshot

A formal financial-services presentation system built on the NatWest Group brand identity. Dark slides use deep purple (`#4B0082`) with white headlines and gold (`#F5C518`) subtitle accents. Content slides use a clean white canvas with deep purple (`#3C1053`) headings and mid-purple (`#6B2A8B`) secondary text. Cards use a pale lilac fill (`#EDD9F5`) with lavender borders (`#C09FD4`). The type system pairs Playfair Display (editorial serif for headings) with IBM Plex Sans (clean sans for body and UI). The overall aesthetic borrows from NatWest investor presentations — measured, data-dense, and unmistakably institutional.

## Preview Ingredients

- Palette: dark-bg #4B0082; dark-alt #3C1053; white #FFFFFF; offwhite #F7F4FB; lilac #EDD9F5; gold #F5C518; lavender #C09FD4; mid-purple #6B2A8B; text-dark #3C1053; text-body #333333
- Typography: Playfair Display (headings, editorial serif) + IBM Plex Sans (body, UI) + IBM Plex Mono (labels, code)
- Signature move: Dark-light-dark sandwich — purple hero/divider slides bookend white content slides
- Signature move: Gold `#F5C518` used exclusively for subtitle text on dark purple backgrounds
- Signature move: Pale lilac `#EDD9F5` card fills with `#C09FD4` borders — never solid-colored cards
- Signature move: Section badge labels above titles on dark divider slides (e.g. "SECTION 02")
- Signature move: Left-aligned body text on content slides; centered titles on dark hero slides

## International / CJK Preview Note

- If the preview uses Chinese or other CJK text, keep CJK letter-spacing at 0, loosen line-height, and avoid uppercase transforms on CJK runs.

## Preview Rules

- Build exactly one title slide at 1920x1080 inside the fixed-stage model.
- Preserve the palette, type roles, surface rhythm, and decorative vocabulary described above.
- Use the user's real title/subtitle/context; do not copy demo slide content.
- The rendered preview must look like a real first slide, not a template-selection card.
- Never place internal workflow text on the slide: no `preview`, `generated from`, `preview.md`, `template`, `preset`, `style option`, `Option A/B/C`, file names, paths, or source-doc labels.
- Never place the template name or slug on the slide itself; mention it only in the chat message.
- Never place user requirement notes such as desired vibe, audience, or internal-use labels on the slide unless the user explicitly wants those exact words in the deck.
- Use only real deck content for visible chrome: deck title, real section title, date, author, company, page number, or genuine content phrases from the user material.
- Do not read `template.html` for preview generation.
- Do not read other templates' `design.md` files.
- After the user picks this template for the full deck, read the full design doc before generating final slides.
